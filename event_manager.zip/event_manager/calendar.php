<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit;
}

$user_id = $_SESSION['user_id'];

$conn = new mysqli("localhost", "root", "", "event_calendar");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['add_event'])) {
        $event_name = $_POST['event_name'];
        $start_date = $_POST['start_date'];
        $end_date = $_POST['end_date'];
        $color = $_POST['color'];
        $sql = "INSERT INTO events (user_id, event_name, start_date, end_date, notification_time, color) VALUES ('$user_id', '$event_name', '$start_date', '$end_date', '$color')";
        $conn->query($sql);
    } elseif (isset($_POST['delete_event'])) {
        $event_id = $_POST['event_id'];
        $sql = "DELETE FROM events WHERE id='$event_id' AND user_id='$user_id'";
        $conn->query($sql);
    }
}

$sql = "SELECT * FROM events WHERE user_id='$user_id' ORDER BY start_date";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendar</title>
    <link rel="stylesheet" href="styles.css">
    <link href='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css' rel='stylesheet' />
    <link href='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.print.min.css' rel='stylesheet' media='print' />
    <script src='https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.js'></script>
</head>
<body>
<div class="container">
    <h2>Your Events</h2>
    <a href="logout.php" class="logout-btn">Logout</a>
    <div id='calendar'></div>

    <!-- Add Event Modal -->
    <div id="addEventModal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Add Event</h2>
            <form id="addEventForm">
                <label for="event_name">Event name</label>
                <input type="text" id="event_name" name="event_name" required>
                <label for="start_date">Start date</label>
                <input type="date" id="start_date" name="start_date" required>
                <label for="end_date">End date</label>
                <input type="date" id="end_date" name="end_date">
                <label for="color">Color</label>
                <input type="color" id="color" name="color">
                <button type="submit">Add Event</button>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#calendar').fullCalendar({
        editable: true,
        events: 'load_events.php', // PHP file to load events from the database
        selectable: true,
        selectHelper: true,
        select: function(start, end) {
            $('#addEventModal').show();
            $('#start_date').val(moment(start).format('YYYY-MM-DD'));
            $('#end_date').val(moment(end).format('YYYY-MM-DD'));
        },
        eventClick: function(event) {
            if (confirm("Are you sure you want to delete this event?")) {
                var eventId = event.id;
                $.ajax({
                    url: 'delete_event.php',
                    type: 'POST',
                    data: {id: eventId},
                    success: function() {
                        $('#calendar').fullCalendar('refetchEvents');
                    }
                });
            }
        }
    });

    // Close modal on clicking the close button
    $('.close').on('click', function() {
        $('#addEventModal').hide();
    });

    // Add event form submission
    $('#addEventForm').on('submit', function(event) {
        event.preventDefault();
        var eventData = {
            event_name: $('#event_name').val(),
            start_date: $('#start_date').val(),
            end_date: $('#end_date').val(),
            color: $('#color').val()
        };
        $.ajax({
            url: 'add_event.php',
            type: 'POST',
            data: eventData,
            success: function() {
                $('#calendar').fullCalendar('refetchEvents');
                $('#addEventModal').hide();
            }
        });
    });
});
</script>

</body>
</html>
<?php
$conn->close();
?>
