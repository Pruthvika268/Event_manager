<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $event_id = $_POST['id'];

    $conn = new mysqli("localhost", "root", "", "event_calendar");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "DELETE FROM events WHERE id='$event_id'";
    $conn->query($sql);
    $conn->close();
}
?>
