<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $event_name = $_POST['event_name'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $color = $_POST['color'];
    $user_id = $_SESSION['user_id'];

    $conn = new mysqli("localhost", "root", "", "event_calendar");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO events (user_id, event_name, start_date, end_date, color) VALUES ('$user_id', '$event_name', '$start_date', '$end_date', '$color')";
    $conn->query($sql);
    $conn->close();
}
?>
